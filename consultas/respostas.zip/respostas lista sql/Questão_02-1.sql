/*QUESTÃO 1 - Base 2 MAILORDER*/
SELECT pname FROM parts
WHERE price < 20.00